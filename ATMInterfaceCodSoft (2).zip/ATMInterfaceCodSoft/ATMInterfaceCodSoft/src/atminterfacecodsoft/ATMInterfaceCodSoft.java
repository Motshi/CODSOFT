
package atminterfacecodsoft;

import javax.swing.JButton;


public class ATMInterfaceCodSoft {

    public static void main(String[] args) {
       MyFrame frame=new MyFrame();
        
      
    }
    
}
