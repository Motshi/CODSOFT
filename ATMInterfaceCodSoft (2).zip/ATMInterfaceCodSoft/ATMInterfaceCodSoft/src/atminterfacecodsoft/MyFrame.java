

package atminterfacecodsoft;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.*;

class MyFrame extends JFrame implements ActionListener {
    private static double amt = 0;

    private JButton deposit;
    private JButton withdraw;
    private JButton checkBalance;
     private JButton exitButton ;
    private JTextArea messageArea;

    public MyFrame() {
        JLabel titleLabel = new JLabel("Batho ATM");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.GREEN);
        titleLabel.setBounds(200, 20, 200, 40);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel);

        JLabel subTitleLabel = new JLabel("How may we assist you today?");
       
        subTitleLabel.setBounds(200, 60, 200, 40);
        subTitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(subTitleLabel);

        deposit = new JButton();
        deposit.setBounds(200, 100, 200, 40);
        deposit.setText("Deposit");
        deposit.addActionListener(this);

        withdraw = new JButton();
        withdraw.setBounds(200, 150, 200, 40);
        withdraw.setText("Withdraw");
        withdraw.addActionListener(this);

        checkBalance = new JButton();
        checkBalance.setBounds(200, 200, 200, 40);
        checkBalance.setText("Balance");
        checkBalance.addActionListener(this);
        
        exitButton = new JButton();
exitButton.setBounds(200, 250, 200, 40);
exitButton.setText("Exit");
exitButton.addActionListener(this);


        messageArea = new JTextArea();
        messageArea.setBounds(50, 250, 500, 200);
        messageArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(messageArea);
        scrollPane.setBounds(50, 250, 500, 200);
        add(scrollPane);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setSize(600, 500);
        setVisible(true);
        add(deposit);
        add(withdraw);
        add(checkBalance);
        add(exitButton);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == deposit) {
            clear();
            deposit();
        } else if (e.getSource() == withdraw) {
              clear();
            withdraw();
          
        } else if (e.getSource() == checkBalance) {
              clear();
            checkBalance();
        }else if (e.getSource() == exitButton) {
    System.exit(0);
}
    }

      public void deposit() {
        DecimalFormat format = new DecimalFormat("#.##");
        double depositAmt = 0;
        try {
            depositAmt = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter the amount you wish to deposit.", "Deposit", JOptionPane.INFORMATION_MESSAGE));
        } catch (NumberFormatException t) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        amt += depositAmt;
        String msg = "You have successfully deposited R" + depositAmt + " into your account";
        
        messageArea.append(msg + "\n");
    }

    public void withdraw() {
        DecimalFormat format = new DecimalFormat("#.##");
        double requestedAmt = 0;
        try {
            requestedAmt = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter the amount you want to withdraw.", "Withdrawal", JOptionPane.INFORMATION_MESSAGE));
            if (requestedAmt > amt) {
                JOptionPane.showMessageDialog(null, "Insufficient funds you have R" + format.format(amt) + " left and you have requested " + requestedAmt, null, WIDTH);
            } else {
                amt -= requestedAmt;
                String msg = "Your withdrawal was successful -R" + format.format(requestedAmt);
                messageArea.append(msg + "\n");
            }
        } catch (NumberFormatException y) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void checkBalance() {
        messageArea.append("Your remaining balance is R" + amt+"0" + "\n");
    }
    
    public void clear(){
        messageArea.setText("");
    }
}