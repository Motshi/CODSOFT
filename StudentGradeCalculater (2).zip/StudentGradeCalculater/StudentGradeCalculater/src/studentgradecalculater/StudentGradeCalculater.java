/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentgradecalculater;

import javax.swing.JOptionPane;

public class StudentGradeCalculater {

 
    public static void main(String[] args) {
        int mark=0,sum=0;
        String grade = null;
        double avg=0;
        int numSubjects=Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the number of subjects you are doing"));
        for (int i = 0; i < numSubjects; i++) {
             mark=Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the mark for subject "+(i+1)));
             sum+=mark;
        }
        avg=(sum/numSubjects);
        if (avg >= 80) {
            grade = "A";
        } else if (avg >= 70) {
            grade = "B";
        } else if (avg >= 60) {
            grade = "C";
        } else if (avg >= 50) {
            grade = "D";
        } else if (avg >= 40) {
            grade = "E";
        } else {
            grade = "F";
        }
      
        JOptionPane.showMessageDialog(null, "Your average is "+avg+"%\nand your grade symbol is "+grade,"Average summary",JOptionPane.INFORMATION_MESSAGE);
    }
    
}
